﻿Imports MySql.Data.MySqlClient

Public Class AllLease
    Private Sub AllLease_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim properties As New Dictionary(Of Integer, String)
        Dim propnown As New Dictionary(Of Integer, Integer)
        Dim owners As New Dictionary(Of Integer, String)

        If OpenConn() Then
            Dim sqlquery As String = "select * from Lease"
            Dim sqlcomm As MySqlCommand = New MySqlCommand(sqlquery, Conn)
            Dim da = New MySqlDataAdapter(sqlcomm)
            Dim dt = New DataTable
            da.Fill(dt)
            DataGridView1.DataSource = dt

        End If


        If OpenConn() Then
            Dim sqlQuery As String = "select * from Property"
            'InputBox("", "", sqlQuery)
            Dim sqlComm As MySqlCommand = New MySqlCommand(sqlQuery, Conn)
            Try
                Dim sqlReader As MySqlDataReader = sqlComm.ExecuteReader()
                While sqlReader.Read()

                    properties.Add(sqlReader.GetValue(0), sqlReader.GetValue(1).ToString())
                    propnown.Add(sqlReader.GetValue(0), sqlReader.GetValue(6))

                End While


            Catch ex As MySqlException
                Console.WriteLine(ex.Message)
            Finally
                Conn.Close()
            End Try
        End If

        If OpenConn() Then
            Dim sqlQuery As String = "select * from Owner"
            'InputBox("", "", sqlQuery)
            Dim sqlComm As MySqlCommand = New MySqlCommand(sqlQuery, Conn)
            Try
                Dim sqlReader As MySqlDataReader = sqlComm.ExecuteReader()
                While sqlReader.Read()

                    owners.Add(sqlReader.GetValue(0), sqlReader.GetValue(1).ToString())
                End While
            Catch ex As MySqlException
                Console.WriteLine(ex.Message)
            Finally
                Conn.Close()
            End Try
        End If



        'If OpenConn() Then
        '    Dim sqlQuery As String = "select * from Lease"
        '    'InputBox("", "", sqlQuery)
        '    Dim sqlComm As MySqlCommand = New MySqlCommand(sqlQuery, Conn)
        '    Try
        '        Dim sqlReader As MySqlDataReader = sqlComm.ExecuteReader()
        '        While sqlReader.Read()

        '            DataGridView1.Rows.Add(sqlReader.GetValue(0).ToString(), properties.Item(sqlReader.GetValue(1)), owners.Item(propnown.Item(sqlReader.GetValue(1))))
        '        End While
        '    Catch ex As MySqlException
        '        Console.WriteLine(ex.Message)
        '    Finally
        '        Conn.Close()
        '    End Try
        'End If

        'For Each kvp As KeyValuePair(Of Integer, String) In properties
        '    Dim v1 As Integer = kvp.Key
        '    Dim v2 As String = kvp.Value
        '    ListView1.Items.Add(v1)
        'Next




    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick


        DataGridView1.CurrentRow.Selected = True


    End Sub
End Class