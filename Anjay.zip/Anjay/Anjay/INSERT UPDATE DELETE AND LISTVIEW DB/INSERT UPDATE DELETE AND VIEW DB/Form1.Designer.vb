﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LISTSHOW = New System.Windows.Forms.ListView()
        Me.CLMID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.CLMNAME = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.BTINSERT = New System.Windows.Forms.Button()
        Me.BTUPDATE = New System.Windows.Forms.Button()
        Me.BTDELETE = New System.Windows.Forms.Button()
        Me.BTSHOW = New System.Windows.Forms.Button()
        Me.TID = New System.Windows.Forms.TextBox()
        Me.TNAMES = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.BTSave = New System.Windows.Forms.Button()
        Me.TxtDBName = New System.Windows.Forms.TextBox()
        Me.TxtPasswordDB = New System.Windows.Forms.TextBox()
        Me.TxtUsernameDB = New System.Windows.Forms.TextBox()
        Me.TxtServer = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'LISTSHOW
        '
        Me.LISTSHOW.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.CLMID, Me.CLMNAME})
        Me.LISTSHOW.FullRowSelect = True
        Me.LISTSHOW.GridLines = True
        Me.LISTSHOW.Location = New System.Drawing.Point(57, 159)
        Me.LISTSHOW.Name = "LISTSHOW"
        Me.LISTSHOW.Size = New System.Drawing.Size(486, 175)
        Me.LISTSHOW.TabIndex = 0
        Me.LISTSHOW.UseCompatibleStateImageBehavior = False
        Me.LISTSHOW.View = System.Windows.Forms.View.Details
        '
        'CLMID
        '
        Me.CLMID.Text = "ID"
        Me.CLMID.Width = 100
        '
        'CLMNAME
        '
        Me.CLMNAME.Text = "NAME"
        Me.CLMNAME.Width = 250
        '
        'BTINSERT
        '
        Me.BTINSERT.Location = New System.Drawing.Point(107, 117)
        Me.BTINSERT.Name = "BTINSERT"
        Me.BTINSERT.Size = New System.Drawing.Size(75, 23)
        Me.BTINSERT.TabIndex = 1
        Me.BTINSERT.Text = "INSERT"
        Me.BTINSERT.UseVisualStyleBackColor = True
        '
        'BTUPDATE
        '
        Me.BTUPDATE.Location = New System.Drawing.Point(188, 117)
        Me.BTUPDATE.Name = "BTUPDATE"
        Me.BTUPDATE.Size = New System.Drawing.Size(75, 23)
        Me.BTUPDATE.TabIndex = 2
        Me.BTUPDATE.Text = "UPDATE"
        Me.BTUPDATE.UseVisualStyleBackColor = True
        '
        'BTDELETE
        '
        Me.BTDELETE.Location = New System.Drawing.Point(269, 117)
        Me.BTDELETE.Name = "BTDELETE"
        Me.BTDELETE.Size = New System.Drawing.Size(75, 23)
        Me.BTDELETE.TabIndex = 3
        Me.BTDELETE.Text = "DELETE"
        Me.BTDELETE.UseVisualStyleBackColor = True
        '
        'BTSHOW
        '
        Me.BTSHOW.Location = New System.Drawing.Point(397, 117)
        Me.BTSHOW.Name = "BTSHOW"
        Me.BTSHOW.Size = New System.Drawing.Size(75, 23)
        Me.BTSHOW.TabIndex = 4
        Me.BTSHOW.Text = "SHOW"
        Me.BTSHOW.UseVisualStyleBackColor = True
        '
        'TID
        '
        Me.TID.Location = New System.Drawing.Point(235, 22)
        Me.TID.Name = "TID"
        Me.TID.Size = New System.Drawing.Size(184, 20)
        Me.TID.TabIndex = 5
        '
        'TNAMES
        '
        Me.TNAMES.Location = New System.Drawing.Point(235, 60)
        Me.TNAMES.Name = "TNAMES"
        Me.TNAMES.Size = New System.Drawing.Size(184, 20)
        Me.TNAMES.TabIndex = 6
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(174, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(18, 13)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "ID"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(174, 63)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(38, 13)
        Me.Label2.TabIndex = 8
        Me.Label2.Text = "NAME"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(567, 42)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(41, 13)
        Me.Label3.TabIndex = 14
        Me.Label3.Text = "Server:"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(532, 67)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(76, 13)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Username DB:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(534, 91)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(74, 13)
        Me.Label5.TabIndex = 16
        Me.Label5.Text = "Password DB:"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(552, 117)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(56, 13)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "DB Name:"
        '
        'BTSave
        '
        Me.BTSave.Location = New System.Drawing.Point(618, 149)
        Me.BTSave.Name = "BTSave"
        Me.BTSave.Size = New System.Drawing.Size(75, 23)
        Me.BTSave.TabIndex = 18
        Me.BTSave.Text = "Save"
        Me.BTSave.UseVisualStyleBackColor = True
        '
        'TxtDBName
        '
        Me.TxtDBName.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.INSERT_UPDATE_DELETE_AND_VIEW_DB.My.MySettings.Default, "mDBName", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.TxtDBName.Location = New System.Drawing.Point(618, 114)
        Me.TxtDBName.Name = "TxtDBName"
        Me.TxtDBName.Size = New System.Drawing.Size(200, 20)
        Me.TxtDBName.TabIndex = 12
        Me.TxtDBName.Text = Global.INSERT_UPDATE_DELETE_AND_VIEW_DB.My.MySettings.Default.mDBName
        '
        'TxtPasswordDB
        '
        Me.TxtPasswordDB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.INSERT_UPDATE_DELETE_AND_VIEW_DB.My.MySettings.Default, "mPassDB", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.TxtPasswordDB.Location = New System.Drawing.Point(618, 88)
        Me.TxtPasswordDB.Name = "TxtPasswordDB"
        Me.TxtPasswordDB.Size = New System.Drawing.Size(182, 20)
        Me.TxtPasswordDB.TabIndex = 11
        Me.TxtPasswordDB.Text = Global.INSERT_UPDATE_DELETE_AND_VIEW_DB.My.MySettings.Default.mPassDB
        '
        'TxtUsernameDB
        '
        Me.TxtUsernameDB.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.INSERT_UPDATE_DELETE_AND_VIEW_DB.My.MySettings.Default, "mUserDB", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.TxtUsernameDB.Location = New System.Drawing.Point(618, 64)
        Me.TxtUsernameDB.Name = "TxtUsernameDB"
        Me.TxtUsernameDB.Size = New System.Drawing.Size(200, 20)
        Me.TxtUsernameDB.TabIndex = 10
        Me.TxtUsernameDB.Text = Global.INSERT_UPDATE_DELETE_AND_VIEW_DB.My.MySettings.Default.mUserDB
        '
        'TxtServer
        '
        Me.TxtServer.DataBindings.Add(New System.Windows.Forms.Binding("Text", Global.INSERT_UPDATE_DELETE_AND_VIEW_DB.My.MySettings.Default, "mServer", True, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged))
        Me.TxtServer.Location = New System.Drawing.Point(618, 39)
        Me.TxtServer.Name = "TxtServer"
        Me.TxtServer.Size = New System.Drawing.Size(150, 20)
        Me.TxtServer.TabIndex = 9
        Me.TxtServer.Text = Global.INSERT_UPDATE_DELETE_AND_VIEW_DB.My.MySettings.Default.mServer
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(867, 380)
        Me.Controls.Add(Me.BTSave)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TxtDBName)
        Me.Controls.Add(Me.TxtPasswordDB)
        Me.Controls.Add(Me.TxtUsernameDB)
        Me.Controls.Add(Me.TxtServer)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TNAMES)
        Me.Controls.Add(Me.TID)
        Me.Controls.Add(Me.BTSHOW)
        Me.Controls.Add(Me.BTDELETE)
        Me.Controls.Add(Me.BTUPDATE)
        Me.Controls.Add(Me.BTINSERT)
        Me.Controls.Add(Me.LISTSHOW)
        Me.Name = "Form1"
        Me.Text = "WITH LISTVIEW"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents LISTSHOW As ListView
    Friend WithEvents CLMID As ColumnHeader
    Friend WithEvents CLMNAME As ColumnHeader
    Friend WithEvents BTINSERT As Button
    Friend WithEvents BTUPDATE As Button
    Friend WithEvents BTDELETE As Button
    Friend WithEvents BTSHOW As Button
    Friend WithEvents TID As TextBox
    Friend WithEvents TNAMES As TextBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents TxtServer As TextBox
    Friend WithEvents TxtUsernameDB As TextBox
    Friend WithEvents TxtPasswordDB As TextBox
    Friend WithEvents TxtDBName As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents BTSave As Button
End Class
