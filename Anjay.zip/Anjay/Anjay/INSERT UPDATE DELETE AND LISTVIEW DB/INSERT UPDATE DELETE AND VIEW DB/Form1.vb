﻿Imports MySql.Data.MySqlClient

Public Class Form1
#Region "declare"
    Dim mycmd As New MySqlCommand
    Dim myconnection As New DTConnection
    Dim objreader As MySqlDataReader
#End Region
    Private Sub BTINSERT_Click(sender As Object, e As EventArgs) Handles BTINSERT.Click
        mycmd.Connection = myconnection.open
        mycmd.CommandText = "insert into tb_testing(id,names) values('" & TID.Text & "','" & TNAMES.Text & "')"
        mycmd.ExecuteNonQuery()
        myconnection.close()
        MsgBox("Data added !!", MsgBoxStyle.Information, "Notice..")
    End Sub

    Private Sub BTUPDATE_Click(sender As Object, e As EventArgs) Handles BTUPDATE.Click
        mycmd.Connection = myconnection.open
        mycmd.CommandText = "update tb_testing set names='" & TNAMES.Text & "' where id='" & TID.Text & "'"
        mycmd.ExecuteNonQuery()
        myconnection.close()
        MsgBox("Data changed !!", MsgBoxStyle.Information, "Notice..")
    End Sub

    Private Sub BTDELETE_Click(sender As Object, e As EventArgs) Handles BTDELETE.Click
        mycmd.Connection = myconnection.open
        mycmd.CommandText = "delete from tb_testing where id='" & TID.Text & "'"
        mycmd.ExecuteNonQuery()
        myconnection.close()
        MsgBox("Data deleted !!", MsgBoxStyle.Information, "Notice..")
    End Sub

    Private Sub BTSHOW_Click(sender As Object, e As EventArgs) Handles BTSHOW.Click
        Try
            Dim isi As ListViewItem
            LISTSHOW.Items.Clear()
            mycmd.Connection = myconnection.open
            mycmd.CommandText = "select * from tb_testing"
            objreader = mycmd.ExecuteReader
            While objreader.Read
                isi = LISTSHOW.Items.Add(objreader.Item("id").ToString)
                isi.SubItems.Add(objreader.Item("names").ToString)
            End While
            myconnection.close()
        Catch ex As Exception
            MessageBox.Show(ex.Message)
        End Try
    End Sub

    Private Sub LISTSHOW_SelectedIndexChanged(sender As Object, e As EventArgs) Handles LISTSHOW.SelectedIndexChanged
        Dim index As Integer
        If LISTSHOW.SelectedItems.Count = 0 Then Exit Sub
        With LISTSHOW
            index = .SelectedIndices(0)
            TID.Text = .Items(index).Text
            TNAMES.Text = .Items(index).SubItems(1).Text
        End With
        'Update sub
    End Sub

    Private Sub BTSave_Click(sender As Object, e As EventArgs) Handles BTSave.Click
        'Saving the configuration
        My.Settings.mUserDB = TxtUsernameDB.Text
        My.Settings.mPassDB = TxtPasswordDB.Text
        My.Settings.mServer = TxtServer.Text
        My.Settings.mDBName = TxtDBName.Text
        My.Settings.Save()
        MsgBox("Your server configuration has saved !", MsgBoxStyle.Information, MsgBoxResult.Ok)
        Application.Restart()
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'Load the last setting
        My.Settings.Reload()
        'TxtUsernameDB.Text = My.Settings.mUserDB
        'TxtPasswordDB.Text = My.Settings.mPassDB
        'TxtServer.Text = My.Settings.mServer
        'TxtDBName.Text = My.Settings.mDBName
    End Sub
End Class
