﻿Imports MySql.Data.MySqlClient
Public Class DTConnection
    Dim conect As New MySqlConnection("server='" & My.Settings.mServer & "';
    user='" & My.Settings.mUserDB & "';
    password='" & My.Settings.mPassDB & "';
    database='" & My.Settings.mDBName & "'")
    Public Function open() As MySqlConnection
        Try
            conect.Open()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Return conect
    End Function

    Public Function close() As MySqlConnection
        Try
            conect.Close()
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Return conect
    End Function
End Class
