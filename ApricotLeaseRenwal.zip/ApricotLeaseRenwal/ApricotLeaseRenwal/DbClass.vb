﻿Imports MySql.Data.MySqlClient

Module DbClass
    Public Conn As New MySqlConnection
    Dim Result As Boolean
    Dim Strconn As String
    Public Function OpenConn() As Boolean
        Try
            If Conn.State = ConnectionState.Closed Then
                Strconn = "server=management.apricot.ke;Port=3306;Database=apricotk_tenancy_management;UID=apricotk_abhi;password=SkYfAlL$007!;"
                Conn.ConnectionString = Strconn
                Conn.Open()
                Result = True
            End If
        Catch ex As Exception
            Result = False
        End Try
        Return Result
    End Function

End Module
