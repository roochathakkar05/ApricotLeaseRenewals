﻿Imports MySql.Data.MySqlClient

Public Class NewLease



    Private Sub NewLease_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        get_TenantList()
        get_PropertyList()
    End Sub
    Function get_TenantList()
        If OpenConn() Then
            Dim query1 As String
            query1 = "Select CONCAT(Fname,' ',Lname) AS Fullname FROM Tenant;"
            'InputBox("", "", query1)
            Dim cmd As MySqlCommand = New MySqlCommand(query1, Conn)
            Dim reader As MySqlDataReader
            Try
                reader = cmd.ExecuteReader()
                While reader.Read()
                    cbtenant.Items.Add(reader.GetValue(0).ToString())
                End While
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Conn.Close()
            End Try
        End If
        Return True
    End Function
    Function get_PropertyList()
        If OpenConn() Then
            Dim query1 As String
            query1 = "Select Name FROM Property;"
            'InputBox("", "", query1)
            Dim cmd As MySqlCommand = New MySqlCommand(query1, Conn)
            Dim reader As MySqlDataReader
            Try
                reader = cmd.ExecuteReader()
                While reader.Read()
                    cbproperty.Items.Add(reader.GetValue(0).ToString())
                End While
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Conn.Close()
            End Try
        End If
        Return True
    End Function
End Class