﻿Imports MySql.Data.MySqlClient

Public Class NewLease
    Dim TenantId As String
    Dim PropertyId As String
    Dim StartDate As Date
    Dim Term As String
    Dim EndDate As Date
    Dim IncDate As Date
    Dim TotalDep As Integer
    Private Sub NewLease_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        get_TenantList()
        get_PropertyList()
        DateTimePicker1.Value = DateTime.Now
    End Sub
    Function get_TenantList()
        If OpenConn() Then
            Dim query1 As String
            query1 = "Select Fname FROM Tenant;"
            'InputBox("", "", query1)
            Dim cmd As MySqlCommand = New MySqlCommand(query1, Conn)
            Dim reader As MySqlDataReader
            Try
                reader = cmd.ExecuteReader()
                While reader.Read()
                    cbtenant.Items.Add(reader.GetValue(0).ToString())
                End While
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Conn.Close()
            End Try
        End If
        Return True
    End Function
    Function get_PropertyList()
        If OpenConn() Then
            Dim query1 As String
            query1 = "Select Name FROM Property;"
            'InputBox("", "", query1)
            Dim cmd As MySqlCommand = New MySqlCommand(query1, Conn)
            Dim reader As MySqlDataReader
            Try
                reader = cmd.ExecuteReader()
                While reader.Read()
                    cbproperty.Items.Add(reader.GetValue(0).ToString())
                End While
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Conn.Close()
            End Try
        End If
        Return True
    End Function
    Function gettnum(ByVal names As String) As String

        If OpenConn() Then
            Dim sqlQuery As String = "select Tenant_Id from Tenant where FName = '" & names & "'"
            InputBox("", "", sqlQuery)
            Dim sqlComm As MySqlCommand = New MySqlCommand(sqlQuery, Conn)
            Try
                Dim sqlReader As MySqlDataReader = sqlComm.ExecuteReader()
                While sqlReader.Read()

                    TenantId = sqlReader.GetValue(0).ToString()
                End While
            Catch ex As MySqlException
                Console.WriteLine(ex.Message)
            Finally
                Conn.Close()
            End Try
        End If
        Return TenantId
    End Function
    Function getpnum(ByVal names As String) As String

        If OpenConn() Then
            Dim sqlQuery As String = "select Property_ID from Property where Name = '" & names & "'"
            InputBox("", "", sqlQuery)
            Dim sqlComm As MySqlCommand = New MySqlCommand(sqlQuery, Conn)
            Try
                Dim sqlReader As MySqlDataReader = sqlComm.ExecuteReader()
                While sqlReader.Read()

                    PropertyId = sqlReader.GetValue(0).ToString()
                End While
            Catch ex As MySqlException
                Console.WriteLine(ex.Message)
            Finally
                Conn.Close()
            End Try
        End If
        Return PropertyId
    End Function

    Private Sub cbtenant_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbtenant.SelectedIndexChanged
        Dim tenant As String
        tenant = cbtenant.SelectedItem.ToString()
        gettnum(tenant)
    End Sub

    Private Sub cbproperty_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbproperty.SelectedIndexChanged
        Dim propertyname As String
        propertyname = cbtenant.SelectedItem.ToString()
        gettnum(propertyname)
    End Sub

    Private Sub TextBox1_TextChanged(sender As Object, e As EventArgs) Handles txtTerm.TextChanged
        If txtTerm.Text = "" Then
            Label22.Text = "Please enter term of the lease."
        Else
            StartDate = DateTimePicker1.Value
            Term = txtTerm.Text
            EndDate = DateTimePicker1.Value.AddMonths(Term)
            Label8.Text = EndDate.ToString("yyyy-MM-dd")
            Label9.Text = EndDate.ToString("yyyy-MM-dd")
            Label13.Text = EndDate.ToString("yyyy-MM-dd")
        End If
    End Sub

    Private Sub TextBox4_TextChanged(sender As Object, e As EventArgs) Handles txtrent.TextChanged
        If txtinidep.Text = "" Then
            Label22.Text = "Please enter the initial deposit"
        ElseIf txtrent.Text = "" Then
            Label22.Text = "Please enter the rent"
        Else
            TotalDep = Integer.Parse(txtinidep.Text) + Integer.Parse(txtrent.Text)
            Label21.Text = TotalDep.ToString()

        End If
    End Sub
End Class