﻿Imports MySql.Data.MySqlClient
Public Class NewProperty
    Dim cmd As New MySqlCommand
    Dim reader As MySqlDataReader
    Dim query1 As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TxtName.Text = "" Then
            Label7.Text = "Please enter the name of the property."
            TxtName.Focus()
        ElseIf TxtAddressL1.Text = "" Then
            Label7.Text = "Please enter the address of the property."
            TxtAddressL1.Focus()
        ElseIf TxtAddressL2.Text = "" Then
            Label7.Text = "Please enter the address of the property."
            TxtAddressL2.Focus()
        ElseIf TxtCity.Text = "" Then
            Label7.Text = "Please enter the city the property located in."
            TxtCity.Focus()
        ElseIf (String.IsNullOrEmpty(CbType.SelectedItem)) Then
            Label7.Text = "Select the type of the property"
        Else
            If OpenConn() Then
                'MsgBox("Success")
                Try
                    query1 = "INSERT INTO Property(Property_ID,Name,Type,AddressOne,AddressTwo,City) VALUES('','" & TxtName.Text & "','" & CbType.SelectedItem.ToString & "','" & TxtAddressL1.Text & "','" & TxtAddressL2.Text & "','" & TxtCity.Text & "');"
                    Dim cmd As New MySqlCommand(query1, Conn)
                    'InputBox(query1, query1, query1)
                    reader = cmd.ExecuteReader()
                    Conn.Close()
                    MsgBox("New Property has been added successfully.")
                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    Conn.Close()
                End Try
            Else
                MsgBox("Connection Failed: Please check your internet connectivity")
            End If
        End If

    End Sub
End Class
