﻿Imports MySql.Data.MySqlClient
Public Class NewProperty
    Dim cmd As New MySqlCommand
    Dim reader As MySqlDataReader
    Dim query1 As String
    Dim Ownerid As String

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If TxtName.Text = "" Then
            Label7.Text = "Please enter the name of the property."
            TxtName.Focus()
        ElseIf TxtAddressL1.Text = "" Then
            Label7.Text = "Please enter the address of the property."
            TxtAddressL1.Focus()
        ElseIf TxtAddressL2.Text = "" Then
            Label7.Text = "Please enter the address of the property."
            TxtAddressL2.Focus()
        ElseIf TxtCity.Text = "" Then
            Label7.Text = "Please enter the city the property located in."
            TxtCity.Focus()
        ElseIf (String.IsNullOrEmpty(CbType.SelectedItem)) Then
            Label7.Text = "Select the type of the property"
        Else
            If OpenConn() Then
                'MsgBox("Success")
                Try
                    query1 = "INSERT INTO Property(Property_ID,Name,Type,AddressOne,AddressTwo,City,Owner_Id) VALUES('','" & TxtName.Text & "','" & CbType.SelectedItem.ToString & "','" & TxtAddressL1.Text & "','" & TxtAddressL2.Text & "','" & TxtCity.Text & "','" & Ownerid & "');"
                    Dim cmd As New MySqlCommand(query1, Conn)
                    InputBox("", "", query1)
                    reader = cmd.ExecuteReader()
                    Conn.Close()
                    MsgBox("New Property has been added successfully.")
                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    Conn.Close()
                End Try
            Else
                MsgBox("Connection Failed: Please check your internet connectivity")
            End If
        End If

    End Sub
    Function get_OwnerList()
        If OpenConn() Then
            Dim query1 As String
            query1 = "Select Fname FROM Owner;"
            InputBox("", "", query1)
            Dim cmd As MySqlCommand = New MySqlCommand(query1, Conn)
            Dim reader As MySqlDataReader
            Try
                reader = cmd.ExecuteReader()
                While reader.Read()
                    cbowner.Items.Add(reader.GetValue(0).ToString())
                End While
            Catch ex As Exception
                MsgBox(ex.Message)
            Finally
                Conn.Close()
            End Try
        End If
        Return True
    End Function

    Private Sub NewProperty_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        get_OwnerList()
    End Sub

    Private Sub cbowner_SelectedIndexChanged(sender As Object, e As EventArgs) Handles cbowner.SelectedIndexChanged
        Dim Selectedowner As String
        Selectedowner = cbowner.SelectedItem.ToString()
        getonum(Selectedowner)
    End Sub
    Function getonum(ByVal names As String) As String

        If OpenConn() Then
            Dim sqlQuery As String = "select Owner_ID from Owner where FName = '" & names & "'"
            InputBox("", "", sqlQuery)
            Dim sqlComm As MySqlCommand = New MySqlCommand(sqlQuery, Conn)
            Try
                Dim sqlReader As MySqlDataReader = sqlComm.ExecuteReader()
                While sqlReader.Read()

                    Ownerid = sqlReader.GetValue(0).ToString()
                End While
            Catch ex As MySqlException
                Console.WriteLine(ex.Message)
            Finally
                Conn.Close()
            End Try
        End If
        Return Ownerid
    End Function
End Class
