﻿Imports MySql.Data.MySqlClient

Public Class NewOwner
    Dim reader As MySqlDataReader
    Dim query1 As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        If txtfname.Text = "" Then
            Label12.Text = "Please enter the First name of the owner"
            txtfname.Focus()
        ElseIf txtpa.Text = "" Then
            Label12.Text = "Please enter the Postal Address of the owner"
            txtpa.Focus()
        ElseIf txtphone.Text = "" Then
            Label12.Text = "Please enter the Phone number of the owner"
            txtphone.Focus()
        ElseIf txtemail.Text = "" Then
            Label12.Text = "Please enter the Email of the owner"
            txtemail.Focus()
        Else
            If OpenConn() Then
                'MsgBox("Success")
                Try
                    query1 = "INSERT INTO Owner(Owner_Id,Fname,PostAdd,Id,Cert,Mobile,Email) VALUES('','" & txtfname.Text & "','" & txtpa.Text & "','" & txtid.Text & "','" & txtcert.Text & "','" & txtphone.Text & "','" & txtemail.Text & "');"
                    Dim cmd As New MySqlCommand(query1, Conn)
                    ' InputBox(query1, query1, query1)
                    reader = cmd.ExecuteReader()
                    Conn.Close()
                    MsgBox("New Owner has been added successfully.")
                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    Conn.Close()
                End Try
            Else
                MsgBox("Connection Failed: Please check your internet connectivity")
            End If
        End If
    End Sub

    Private Sub NewOwner_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class