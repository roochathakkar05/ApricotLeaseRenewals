﻿Imports MySql.Data.MySqlClient
Public Class NewTenant
    Dim reader As MySqlDataReader
    Dim query1 As String
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If txtfname.Text = "" Then
            Label12.Text = "Please enter the First name of the tenant"
            txtfname.Focus()
        ElseIf txtlname.Text = "" Then
            Label12.Text = "Please enter the Last name of the tenant"
            txtlname.Focus()
        ElseIf txtpa.Text = "" Then
            Label12.Text = "Please enter the Postal Address of the tenant"
            txtpa.Focus()
        ElseIf txtpin.Text = "" Then
            Label12.Text = "Please enter the PIN No. of the tenant"
            txtpin.Focus()
        ElseIf txtphone.Text = "" Then
            Label12.Text = "Please enter the Phone number of the tenant"
            txtphone.Focus()
        ElseIf txtemail.Text = "" Then
            Label12.Text = "Please enter the Email of the tenant"
            txtemail.Focus()
        Else
            If OpenConn() Then
                'MsgBox("Success")
                Try
                    query1 = "INSERT INTO Tenant(Tenant_Id,Fname,Lname,PostAdd,Pin,Id,Cert,Mobile,Email) VALUES('','" & txtfname.Text & "','" & txtlname.Text & "','" & txtpa.Text & "','" & txtpin.Text & "','" & txtid.Text & "','" & txtcert.Text & "','" & txtphone.Text & "','" & txtemail.Text & "');"
                    Dim cmd As New MySqlCommand(query1, Conn)
                    ' InputBox(query1, query1, query1)
                    reader = cmd.ExecuteReader()
                    Conn.Close()
                    MsgBox("New Tenant has been added successfully.")
                Catch ex As Exception
                    MsgBox(ex.Message)
                Finally
                    Conn.Close()
                End Try
            Else
                MsgBox("Connection Failed: Please check your internet connectivity")
            End If
        End If
    End Sub

    Private Sub NewTenant_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub
End Class